var express = require('express');
var app = express();

app.use('/a_scripts', express.static(__dirname + '/node_modules/angular/'));
app.use('/aui_router_scripts', express.static(__dirname + '/node_modules/angular-ui-router/'));
app.use('/a_animate_scripts', express.static(__dirname + '/node_modules/angular-animate/'))
app.use('/amaterial_scripts', express.static(__dirname + '/node_modules/angular-material/'));
app.use('/amaterial_icons_scripts', express.static(__dirname + '/node_modules/angular-material-icons/'));
app.use('/a_aria_scripts', express.static(__dirname + '/node_modules/angular-aria/'));



app.use(express.static(__dirname + '/webapp'));	


app.listen(3000);