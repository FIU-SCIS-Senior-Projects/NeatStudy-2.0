


angular.module('dataentry', []).controller('dataentry', ['$scope','$mdSidenav','$stateParams', function($scope,$mdSidenav,$stateParams) {

$scope.currentNavItem = 'joy';
$scope.dates = [];
if($stateParams.joy)
$scope.categories=['Inner Peace','Fitness','Family'];

$scope.joy=function(){
$scope.categories=['Inner Peace','Fitness','Family'];
};
$scope.passion=function(){
$scope.categories=['Leadership','Neatlife']
};
$scope.givingback= function(){
$scope.categories=['Agile work','Community']
};
var startDate = moment().format('MM/DD/YYYY');
var endDate = moment(startDate).add(14, 'day').format('l');
var itr = moment.twix(new Date(startDate),new Date(endDate)).iterate("days");
var range=[];
while(itr.hasNext()){
range.push(itr.next().format("MM/DD"))
}
$scope.dates = range;

$scope.toggleLeft = buildToggler('left');
    $scope.toggleRight = buildToggler('right');

    function buildToggler(componentId) {
      return function() {
        $mdSidenav(componentId).toggle();
      };
    }

}]);

