angular.module('routes', ['ui.router'])
	.config(function($urlRouterProvider, $stateProvider) 
{
        $urlRouterProvider.otherwise('/dataentry');
		$stateProvider
            .state('dataentry', {
                url: '/dataentry',
                templateUrl: 'features/dataentry/dataentry.html',
                controller: 'dataentry',
                controllerAs: 'de'
            })
            .state('joy',{
            	url:'/dataentry/:joy',
            	templateUrl: 'features/dataentry/dataentry.html',
                controller: 'dataentry',
                controllerAs: 'de'
            })
           .state('passion',{
            	url:'/dataentry/:passion',
            	templateUrl: 'features/dataentry/dataentry.html',
                controller: 'dataentry',
                controllerAs: 'de'
            })
            .state('givingback',{
            	url:'/dataentry/givingback',
            	templateUrl: 'features/dataentry/dataentry.html',
                controller: 'dataentry',
                controllerAs: 'de'
            })
});        