angular.module('neatapp',[
	'routes',
	'dataentry','ngMaterial','ngMdIcons']);