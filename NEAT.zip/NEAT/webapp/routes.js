angular.module('routes', ['ui.router'])
	.config(function($urlRouterProvider, $stateProvider) 
{
        $urlRouterProvider.otherwise('/');
		$stateProvider
            .state('dataentry', {
                url: '/',
                templateUrl: '/features/dataentry/dataentry.html',
                controller: 'dataentry',
                controllerAs: 'de'
            })
});        