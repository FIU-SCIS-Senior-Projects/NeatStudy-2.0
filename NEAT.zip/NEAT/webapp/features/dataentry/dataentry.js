
(function(){

angular.module('dataentry', ['dataentryservice'])


.controller('dataentry', ['$scope','dataentry_service', function($scope,dataentry_service) {

$scope.currentNavItem = 'joy';
$scope.progress = 35;



init();

function init(){
	dataentry_service.getJoy_data(function(data){
		$scope.joy_data = data;
	});

}


$scope.joy = function(){
	dataentry_service.getJoy_data(function(data){
		$scope.joy_data = data;
	});
}


}])

})();














