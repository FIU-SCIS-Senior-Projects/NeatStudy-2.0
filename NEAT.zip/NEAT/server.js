var express = require('express');
var mongojs = require('mongojs');
var app = express();
var db = mongojs('neat_db',['joy']);


db.on('error', function(err){
	console.log('Error: could not connect to MongoDB.');
});
db.once('open', function() {
  console.log("we are connected");
});



app.use('/a_scripts', express.static(__dirname + '/node_modules/angular/'));
app.use('/aui_router_scripts', express.static(__dirname + '/node_modules/angular-ui-router/'));
app.use('/a_animate_scripts', express.static(__dirname + '/node_modules/angular-animate/'))
app.use('/amaterial_scripts', express.static(__dirname + '/node_modules/angular-material/'));
app.use('/amaterial_icons_scripts', express.static(__dirname + '/node_modules/angular-material-icons/'));
app.use('/a_aria_scripts', express.static(__dirname + '/node_modules/angular-aria/'));
app.use(express.static(__dirname + '/webapp'));	






app.get('/joy_data',function(req,res){
	console.log("getting req");
          db.joy.find(function(err,joy){
          	if(err) {
                    res.send('There was an error processing');
                } else {
                	console.log("in else state")
                    res.json(joy);
                }


          })


});





app.listen(3000);