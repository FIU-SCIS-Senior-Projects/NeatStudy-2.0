angular.module('dataentry', [])
	.controller('dataentry', ['$scope','dataentry_factory', function($scope,dataentry_factory)
	{

		$scope.currentNavItem = 'joy';
		$scope.isActive = false;

	$scope.toggleActive = function()
	{
    	$scope.isActive = !$scope.isActive;
	};

	.factory('dataentry_factory',function()
	{
		var data ={};

		data.getJoy_data= function(cb)
		{
            var joy_data = [
								{
								"activity_name": "Inner Peace",
								"scores":[0,0,0,0],
								"progress":0
								},

								{
								"activity_name": "Fitness",
								"scores":[0,0,0,0],
								"progress":0
								},

							    {
								"activity_name": "Family",
								"scores":[0,0,0,0],
								"progress":0
								}

							];
			cb(joy_data);

		}
	return data;

});
